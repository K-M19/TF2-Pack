By: K-M19
https://github.com/K-M19/TF2-Pack

Recommended launch options:
-novid -nojoy -particles 1 -nohltv -nosteamcontroller -precachefontchars +sv_allow_point_servercommand always

Install at:
~ \steamapps\common\Team Fortress 2\tf